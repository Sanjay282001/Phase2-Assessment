create database flyawaydb;
use flyawaydb;
create table user(
	Name varchar(20),
    Email varchar(35),
	PassWord varchar(20)
);
insert into user values("sanjay","sanjay@gmail.com","kumar");
select * from user;
DELETE FROM user WHERE name="1";
create table adminlogin(
    Email varchar(35),
	PassWord varchar(20)
);
select * from adminlogin;
insert into adminlogin values("Admin28@gmail.com","sanjay");
create table flight(
	FlightId int,
    Name varchar(20),
    Source varchar(20),
	Destination varchar(20),
	Day varchar(20),
    TicketPrice int
);
select * from flight;
insert into flight values(1,"AirIndia","India","UK","SATURDAY",20000);
insert into flight values(2,"AirIndia","India","USA","MONDAY",25000);
insert into flight values(3,"FlyDubai","Dubai","India","Friday",30000);
